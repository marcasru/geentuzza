angular.module('app.routes', [])

.config(function($stateProvider, $urlRouterProvider) {

  // Ionic uses AngularUI Router which uses the concept of states
  // Learn more here: https://github.com/angular-ui/ui-router
  // Set up the various states which the app can be in.
  // Each state's controller can be found in controllers.js
  $stateProvider
    

      .state('menu.geentuzza', {
    url: '/geentuzza',
    views: {
      'side-menu21': {
        templateUrl: 'templates/geentuzza.html',
        controller: 'geentuzzaCtrl'
      }
    }
  })

  .state('menu.fotos', {
    url: '/fotos',
    views: {
      'side-menu21': {
        templateUrl: 'templates/fotos.html',
        controller: 'fotosCtrl'
      }
    }
  })

  .state('menu.mensajes', {
    url: '/mensajes',
    views: {
      'side-menu21': {
        templateUrl: 'templates/mensajes.html',
        controller: 'mensajesCtrl'
      }
    }
  })

  .state('menu', {
    url: '/side-menu21',
    templateUrl: 'templates/menu.html',
    controller: 'menuCtrl'
  })

  .state('login', {
    url: '/login',
    templateUrl: 'templates/login.html',
    controller: 'loginCtrl'
  })

  .state('menu.huaweiP10', {
    url: '/detalle',
    views: {
      'side-menu21': {
        templateUrl: 'templates/huaweiP10.html',
        controller: 'huaweiP10Ctrl'
      }
    }
  })

  .state('carritoDeLaCompra', {
    url: '/carrito',
    templateUrl: 'templates/carritoDeLaCompra.html',
    controller: 'carritoDeLaCompraCtrl'
  })

  .state('nuevoUsuario', {
    url: '/nuevousuario',
    templateUrl: 'templates/nuevoUsuario.html',
    controller: 'nuevoUsuarioCtrl'
  })

$urlRouterProvider.otherwise('/login')


});